document.querySelector("button").addEventListener("click",()=>{
  alert("Purushottam Enterprise এ স্বাগতম!");
});
